const toast = document.getElementById("toast");
let toastTimer;

function notify(message) {
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2600);
}

document.getElementById("play-button").addEventListener("click", () => {
  notify("Le matchmaking multijoueur sera connecté à l'étape suivante.");
});

document.getElementById("plus-button").addEventListener("click", () => {
  notify("La boutique de Cataris sera disponible après la création des comptes.");
});

document.getElementById("profile-button").addEventListener("click", () => {
  notify("Les comptes joueurs seront ajoutés à la prochaine étape.");
});

document.querySelectorAll(".nav-item").forEach((item) => {
  item.addEventListener("click", () => {
    document.querySelectorAll(".nav-item").forEach((nav) => nav.classList.remove("active"));
    item.classList.add("active");
    const labels = {
      accueil: "Tu es déjà sur l'accueil.",
      boutique: "La boutique arrive après le système de comptes.",
      pass: "Le pass de combat sera connecté au système de missions.",
      collection: "Ta collection de skins et de pets arrivera bientôt.",
      classement: "Le classement sera connecté aux statistiques.",
      profil: "Les profils seront disponibles après la création des comptes.",
      reglages: "Les réglages du jeu seront ajoutés prochainement."
    };
    notify(labels[item.dataset.panel] || "Section en préparation.");
  });
});
